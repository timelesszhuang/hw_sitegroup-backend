/**
 * text,set the text bold or italic or underline or with strike through or subscript or superscript
 * Created by peak on 16/8/18.
 */
import dashboard from './dashboard'

export default {
    name: 'text',
    icon: 'fa fa-pencil',
    i18n: 'text',
    dashboard
}

