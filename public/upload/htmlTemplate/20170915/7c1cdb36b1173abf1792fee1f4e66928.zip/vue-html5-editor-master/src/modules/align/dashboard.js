import template from './dashboard.html'
/**
 * Created by peak on 2017/2/10.
 */
export default {
    template
}