/**
 * text align
 * Created by peak on 16/8/18.
 */
import dashboard from './dashboard'

export default {
    name: 'align',
    icon: 'fa fa-align-center',
    i18n: 'align',
    dashboard
}

