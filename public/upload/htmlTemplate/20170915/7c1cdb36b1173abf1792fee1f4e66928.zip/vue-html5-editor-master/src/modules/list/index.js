/**
 * list,ul,ol
 * Created by peak on 16/8/18.
 */
import dashboard from './dashboard'

export default {
    name: 'list',
    icon: 'fa fa-list',
    i18n: 'list',
    dashboard
}