/**
 * editor info
 * Created by peak on 16/8/18.
 */
import dashboard from './dashboard'

export default {
    name: 'info',
    icon: 'fa fa-info',
    i18n: 'info',
    // handler () {
    //
    // },
    // init (editor) {
    //
    // },
    // destroyed(editor){
    //
    // },
    dashboard
}
