import dashboard from './dashboard'
/**
 * fore color and back color
 * Created by peak on 16/8/18.
 */
export default {
    name: 'color',
    icon: 'fa fa-paint-brush',
    i18n: 'color',
    dashboard
}
