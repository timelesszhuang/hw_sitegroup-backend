/**
 * create link
 * Created by peak on 16/8/18.
 */
import dashboard from './dashboard'

export default {
    name: 'link',
    icon: 'fa fa-chain',
    i18n: 'link',
    dashboard
}
