import dashboard from './dashboard'
/**
 * font name and font size
 * Created by peak on 16/8/18.
 */
export default {
    name: 'font',
    icon: 'fa fa-font',
    i18n: 'font',
    dashboard
}