import template from './dashboard.html'

export default {
    template
}