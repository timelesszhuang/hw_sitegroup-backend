### document.execCommand()指令测试结果

command |   IE11    |   chrome  |   firefox
----:   |  :---:    |   :---:   |   :-----
justifyLeft |  Y |  Y | Y  
justifyCenter |  Y |  Y  |  Y
justifyRight |  Y |  Y  |   Y
foreColor  |  Y  | Y |  Y
backColor  |  Y  |  Y   |   Y
removeFormat |  Y  |  Y |   Y
fontName   |   Y  | Y   |   Y
fontSize   |   Y  | Y   |   Y
formatBlock |   Y   |   N   |   N
insertHorizontalRule   |    Y   |   Y   |   Y
insertImage |   Y   |   Y   |   Y
createLink  |   Y   |   Y   |   Y
insertOrderedList   |   Y   |   Y   |   Y
insertUnorderedList |   Y   |   Y   |   Y
insertHTML  |   N   |   Y   |   Y
bold    |   Y   |   Y   |   Y
italic  |   Y   |   Y   |   Y
underline   |   Y   |   Y   |   Y
strikeThrough   |   Y   |   Y   |   Y
subscript   |   Y   |   Y   |   Y
superscript |   Y   |   Y   |   Y
undo    |   Y   |   Y   |   Y
unlink  |   Y   |   Y   |   Y


